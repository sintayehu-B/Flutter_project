class Quote {
  String text;
  String author;

  Quote({required this.text, required this.author});
  
}
